﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using YEDP.Models;

namespace YEDP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CrudController : ControllerBase
    {
        List<crudtodo> Cruddata = new List<crudtodo>()
        {
            new crudtodo(){Id=1,Name="Rajan",Office="ITC ISE",Address="Gurugaon"},
            new crudtodo(){Id=2,Name="Amit",Office="ITC ISE",Address="Gurugram"},
            new crudtodo(){Id=3,Name="Dwarkesh",Office="ITC ISE",Address="Gurugram"},
            new crudtodo(){Id=4,Name="Bharu",Office="ITC ISE",Address="Gurugram"},
            new crudtodo(){Id=5,Name="Laxmi",Office="ITC ISE",Address="Gurugram"}
        };
        [HttpGet]
        public IActionResult Gets()
        {
            if (Cruddata.Count == 0) return BadRequest("No Data");
            return Ok(Cruddata);

        }
        //[HttpGet]
        /*public IActionResult Gets()
        {
            if (Cruddata.Count == 0)
                return NotFound("No Data");
        }
        return OkResult(cruddata);*/
        [HttpGet("getbyId")]
        public IActionResult Get(int id)
        {
            var addid = Cruddata.SingleOrDefault(x => x.Id == id);
            if ( addid!= null)
            {
                return Ok(addid);
            }
            return BadRequest("Id:" + id + " not dound");
        }

        [HttpPost]
        public IActionResult Save(crudtodo newdata)
        {
            Cruddata.Add(newdata);
            if (Cruddata.Count == 0) 
            {
                return BadRequest("Could not add");
            }
            return Ok(Cruddata);
        }

        [HttpDelete] 
        public IActionResult Delete(int id)
        {
            var deleteData = Cruddata.SingleOrDefault(x => x.Id == id);
            if (deleteData == null)
            {
                return BadRequest("Id not found");
            }
            Cruddata.Remove(deleteData);
            return Ok(Cruddata);
        }

        [HttpPut]
        public IActionResult Put(crudtodo newdata)
        {
            var putdata = Cruddata.SingleOrDefault( x => x.Id == newdata.Id);
            if(putdata == null)
            {
                return BadRequest("Data for id:"+newdata.Id+" not available for update");
            }
            foreach(var item in Cruddata) {
                if(item.Id == newdata.Id) {
                    item.Name = newdata.Name;
                    item.Address = newdata.Address;
                    item.Office = newdata.Office;
                }
            }
            return Ok(Cruddata);
        }

    }
}
